package com.libary;

public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student obj = new Student();
		obj.setAddress(" Sector 62 , Noida Uttar Pradesh");
		obj.setId(1);
		obj.setName("raman Sharma");
		
		Student obj1 = new Student("raman", 2, "pune");
		
		System.out.println(obj);
		
		System.out.println("Hashcode( )" + obj.hashCode());
		System.out.println("equals method : " + obj1.equals(obj));
		System.out.println(  obj1 == obj);
	

	}
	
	

}
