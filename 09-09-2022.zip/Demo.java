package mypackage;

public class Demo {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		int i = 7868 ;
		byte b = 1 ;
		float f = 6.78f;
		short s = 20000 ;
		long l= 1236657687 ;
		String r = "classic ";
		boolean b2= true ;
		double d= 6.37 ;
		char c= 'T';
		
		System.out.println("vehicle name :" +r);
		System.out.println("Initial payment :"+s);
		System.out.println("EMI :"+i);
		System.out.println("no of unit :"+b);
		System.out.println("petrol vehicle :"+b2);
		
		
		int f1 = (int) f ;
		System.out.println("Rate of interest :"+f1);
		
		byte s1 =(byte)s;
		System.out.println("EMI Months :"+s1);
		
		short l1 = (short) l;
		System.out.println("Discount :"+l1);
		
		long s11 = (long) s;
		System.out.println("Tax :"+s11);
		
	}
}
