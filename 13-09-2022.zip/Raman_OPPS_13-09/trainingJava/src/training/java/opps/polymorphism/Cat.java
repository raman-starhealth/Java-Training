package training.java.opps.polymorphism;

public class Cat {
	
	public void eat() {
		System.out.println("eating rat");
	}
	
	public static void main(String[] args) {
		
//		overiding method
		Annimals obj1 = new Dog();
		obj1.display();
		
		Annimals obj2 = new Annimals();
		obj2.display();
	}

}
