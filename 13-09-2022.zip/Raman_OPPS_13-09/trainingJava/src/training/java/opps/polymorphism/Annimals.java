package training.java.opps.polymorphism;

public class Annimals {
	
	public void eat() {
		System.out.println("Eating");
	}
	public void display() {
		System.out.println("Annimals class print display() method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Annimals a = new Annimals();
		a.eat();
		Annimals a1 = new Dog();
		a1.eat();

	}

}
