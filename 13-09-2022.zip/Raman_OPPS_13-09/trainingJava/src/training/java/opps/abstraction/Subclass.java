package training.java.opps.abstraction;

class Subclass extends Animal {
	
	
	  public void animalSound() {
	    
	    System.out.println("The pig says: wee wee");
	  }
	}