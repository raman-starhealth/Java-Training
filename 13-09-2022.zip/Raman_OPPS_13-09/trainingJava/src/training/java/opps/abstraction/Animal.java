package training.java.opps.abstraction;

public abstract class Animal {
	
	public abstract void animalSound();
	
	
	   public void sleep() {
	    System.out.println("Zzz");
	    
	  }
	  
}
