package training.java.opps.interfacees;

public class TestInterface {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImplBank obj = new ImplBank() {

			@Override
			public void deposite() {
				// TODO Auto-generated method stub
				System.out.println("depostie method");
			}
		};
		obj.deposite();
		obj.print();

	}

}
