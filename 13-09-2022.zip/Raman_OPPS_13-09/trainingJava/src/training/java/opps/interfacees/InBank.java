package training.java.opps.interfacees;

public interface InBank {
	public abstract  void print(); 

	
	public abstract  void deposite(); 
}
