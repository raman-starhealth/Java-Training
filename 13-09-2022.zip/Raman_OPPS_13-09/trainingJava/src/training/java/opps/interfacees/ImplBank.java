package training.java.opps.interfacees;

public abstract class ImplBank implements InBank{
	
	public void print() {
		System.out.println("print method by interface");
	}

	
}
