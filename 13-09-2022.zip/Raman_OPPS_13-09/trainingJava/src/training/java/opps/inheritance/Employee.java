package training.java.opps.inheritance;

public class Employee extends Child {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c = new Child();
		 c.info();
		 System.out.println( "parent to parent access to properties" + c.toString());
		 
		 Employee emp = new Employee();
		 emp.display();
		 emp.info();
		 
		 System.out.println( "called toString method only : , " + emp);
		
	}
	
	public void   display(){
		System.out.println("dispaly method inheritance by Child Class"); 
	}
	
	

}
