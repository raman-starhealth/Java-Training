package training.collection.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map map=new HashMap();  
	    
	    map.put(1,"Amit");  
	    map.put(5,"Rahul");  
	    map.put(2,"Jai");  
	    map.put(6,"Amit");  
	     
	    Set set=map.entrySet();
	    Iterator itr=set.iterator(); 
	    
	    while(itr.hasNext()){  
	        
	        Map.Entry entry=(Map.Entry)itr.next();  
	        System.out.println(entry.getKey()+" "+entry.getValue());  
	    } 
	    
	    Map<Integer, String> httpErrors = new HashMap<>();
	    httpErrors.put(400, "Bad Request");
	    httpErrors.put(304, "Not Modified");
	    httpErrors.put(200, "OK");
	    httpErrors.put(301, "Moved Permanently");
	    httpErrors.put(500, "Internal Server Error");
	    System.out.println(httpErrors);
	    
	    
	    
	    Map<String, String> mapCountryCodes = new HashMap<>();
	    mapCountryCodes.put("1", "USA");
	    mapCountryCodes.put("44", "United Kingdom");
	    mapCountryCodes.put("33", "France");
	    mapCountryCodes.put("81", "Japan");
	     
	    Set<String> setCodes = mapCountryCodes.keySet();
	    Iterator<String> iterator = setCodes.iterator();
	     
	    while (iterator.hasNext()) {
	        String code = iterator.next();
	        String country = mapCountryCodes.get(code);
	     
	        System.out.println(code + " => " + country);
	    }

	}

}
