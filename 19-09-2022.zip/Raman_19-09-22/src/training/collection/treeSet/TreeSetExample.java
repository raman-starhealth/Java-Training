package training.collection.treeSet;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<Book> set=new TreeSet<Book>();    
	   
		
	    Book b1=new Book(121,"Let us C","Yashwant Kanetkar");    
	    Book b2=new Book(233,"Operating System","Galvin");    
	    Book b3=new Book(101,"Data Communications " , " Networking");    
	     
	    set.add(b1);    
	    set.add(b2);    
	    set.add(b3);    
	   
	    
	    for(Book b:set){    
	    System.out.println(b.id+" "+b.name+" "+b.author+" ");    
	    }    
	}

}
