package training.collection.treeSet;

import java.util.TreeSet;

import javax.swing.text.html.HTMLDocument.Iterator;

public class StudentTreeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeSet<String> set=new TreeSet<String>();  
        set.add("Ravi");  
        set.add("Vijay");  
        set.add("Ajay");  
        System.out.println("Lowest Value: "+set.pollFirst());    
        System.out.println("Highest Value: "+set.pollLast());      
        
        
        set.add("A");  
        set.add("B");  
        set.add("C");  
        set.add("D");  
        set.add("E");  
        System.out.println(set);  
          
        System.out.println("Reverse: "+set.descendingSet());  
          
        System.out.println("Head Set: "+set.headSet("C", true));  
         
        System.out.println("SubSet: "+set.subSet("A", false, "E", true));  
          
        System.out.println("TailSet: "+set.tailSet("C", false));  

	}

}
