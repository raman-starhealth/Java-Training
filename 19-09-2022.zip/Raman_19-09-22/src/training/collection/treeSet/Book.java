package training.collection.treeSet;

 public class Book  implements Comparable<Book>{
	int id;
	String name;
	String author;
	public Book(int id, String name, String author) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int compareTo(Book b) {    
	    if(id>b.id){    
	        return 1;    
	    }else if(id<b.id){    
	        return -1;    
	    }else{    
	    return 0;    
	    }    
	}  
	
	
}

 
 