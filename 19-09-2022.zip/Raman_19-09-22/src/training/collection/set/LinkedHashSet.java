package training.collection.set;

import java.util.Set;

public class LinkedHashSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<String> set = new java.util.LinkedHashSet<String>();
		set.add("Chenaai");
		set.add("pune");
		System.out.println(set);
		
			
	}

}
