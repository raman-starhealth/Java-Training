package training.collection.set;

import java.util.HashSet;
import java.util.Set;

public class SetsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Set<Integer> set = new HashSet<>();

		
		//		set.add(12);
//		set.add(13);
//		System.out.println(set.add(14));
//		set.add(15);
//		System.out.println(set.add(13));
//		
//		System.out.println(set);
		
		Set<StudentHashSet> set1 = new HashSet<StudentHashSet>();
		set1.add(new StudentHashSet(101,"raman", 456));
		set1.add(new StudentHashSet(102,"roshan", 4526));
		set1.add(new StudentHashSet(103,"shubham", 4256));
		System.out.println(set1);
		
	}

}
