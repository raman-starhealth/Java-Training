package training.collection.set;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkedListDeom {
	
	public static void main(String[] agrs) {
		
		List<Integer> list = new LinkedList<Integer>();
		list.add(2332);
		list.add(121);
		list.add(0, 1233);
		
		
		System.out.println(list);
//		Iterator it = list.iterator();
		
//		while(it.hasNext()) {
//			System.out.println(it.next());
//		}
		
		ListIterator<Integer> list2 = list.listIterator();
		while(list2.hasPrevious()) {
			Integer ind = list2.next();
			System.out.println(ind);
		}

	}

}
