package training.fileconcepts;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class IODemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		System.out.println("hello");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			String salary = br.readLine();
			int sal = Integer.parseInt(salary);
			System.out.println(sal + 567);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
