package training.fileconcepts;

import java.io.FileReader;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			FileReader fr = new FileReader("test.txt");
			System.out.println(fr);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
