package com.java8;

public interface StringFunction {
	String run(String str);
}
