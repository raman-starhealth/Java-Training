package com.files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {
	public static void main(String[] args) {
	    try {
	      File myObj = new File("filename.txt");
	      if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName());
	      } else {
	        System.out.println("File already exist.");
	      }
	    } catch (IOException e) {
	      System.out.println(" error occurred.");
	      e.printStackTrace();
	    }
	    
	    
	    try {
	        FileWriter myWriter = new FileWriter("filename.txt");
	        myWriter.write("Files in Java , Star health is good camapny!");
	        myWriter.close();
	        System.out.println("Successfully write file.");
	      } catch (IOException e) {
	        System.out.println("Some  error occurr.");
	        e.printStackTrace();
	      }
	    
	    
	    
	  }
	
	
	

}
