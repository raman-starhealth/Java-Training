package com.streamapi;


import java.util.*;  
import java.util.stream.Collectors;  
class OthersMethods{  
    int id;  
    String name;  
    float price;  
    public OthersMethods(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  
  
