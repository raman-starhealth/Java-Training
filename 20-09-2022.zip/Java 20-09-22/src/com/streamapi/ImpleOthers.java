package com.streamapi;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ImpleOthers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        List<Product> productsList = new ArrayList<Product>();  
		  
		       
		        productsList.add(new Product(1,"HP ",25000f));  
		        productsList.add(new Product(2,"Dell Laptop",30000f));  
		        productsList.add(new Product(3,"Lenevo ",28000f));  
		        productsList.add(new Product(4,"Sony ",28000f));  
		        productsList.add(new Product(5,"Apple ",90000f));  
		          
		        
		        Set<Float> productPriceList =   
		            productsList.stream()  
		            .filter(product->product.price < 30000)   
		            .map(product->product.price)  
		            .collect(Collectors.toSet());    
		        System.out.println(productPriceList);  
		    }  

	

}
