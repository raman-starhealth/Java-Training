package com.java.exceptions.handling;

public class Test1 extends Thread{
 public void run() {
	 System.out.println("test one 1");
 }
}
