package com.java.exceptions.handling;

public class TestMultitasking1 extends Thread {
	
	public void run() {
		System.out.println("print one");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestMultitasking1 task1=new TestMultitasking1();  
		  TestMultitasking1 task2=new TestMultitasking1();  
		  TestMultitasking1 task3=new TestMultitasking1();  
		  
		  task1.start();  
		  task2.start();  
		  task3.start();  

	}

}
