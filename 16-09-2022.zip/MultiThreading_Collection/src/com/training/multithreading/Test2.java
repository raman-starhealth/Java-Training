package com.training.multithreading;

public class Test2 extends Thread{
	 public void run() {
		 System.out.println("test one 2");
	 }
	}
