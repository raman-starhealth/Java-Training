package com.training.multithreading;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List list  = new ArrayList<>();
		list.add("Roshan");
		list.add("Raman");
		list.add("Rahul");
		list.add("Anand");
		System.out.println(list);
		System.out.println("Size of : " + list.size());
		System.out.println("Deleting " + list.remove(3));
		System.out.println("Array after deleting" + list);
		
		List list2 = new ArrayList<>();
		list2.add("21");
		list2.add("55");
		list2.add("77");
		System.out.println(list.addAll(list2 ));
	System.out.println(list.get(3));
		
		Iterator it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
		
		
		List linkedlist = new LinkedList<>();
		linkedlist.add(2);
		linkedlist.add(23);
		linkedlist.add("Hyderbad");
		linkedlist.add(2, "Tambaram");

		System.out.println(linkedlist);
		System.out.println(linkedlist.get(3));
		System.out.println(linkedlist.lastIndexOf(3));
	}

}
