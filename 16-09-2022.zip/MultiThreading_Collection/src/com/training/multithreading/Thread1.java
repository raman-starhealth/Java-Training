package com.training.multithreading;

public class Thread1 extends Thread {

	public static void main(String[] args) {

		Thread2 objB = new Thread2();

		objB.start();

		synchronized (objB) {

			try {

				System.out.println("It will execeute after a gap");

				objB.wait();
			}

			catch (InterruptedException e) {

				e.printStackTrace();
			}

			System.out.println("Total is: " + objB.total);
		}

	}

}
