package com.training.multithreading;

public class Wait_Sleep {
	private static Object obj = new Object();   
	
	public static void main(String[] args) throws InterruptedException{
//		Thread.sleep(2000);
//		
//		System.out.println(Thread.currentThread().getName() + "Thread is working after 2 second");
//		
//		synchronized (obj) {
//			obj.wait(5000);
//			System.out.println(obj + " Object is waiting state and will execute  after 5 second");
//		}
		
		
		
	}
}
